<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dúvidas Frequentes</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<header>
    <nav class="nav-bar">
            <div class="logo">
                <h1>Dúvidas</h1>
            </div>
        <div class="nav-list">
            <ul>
                <li class="nav-item"><a href="./index.php" class="nav-link">Início</li>
                <li class="nav-item"><a href="./sobrenos.php" class="nav-link">Sobre nós</li>
                <li class="nav-item"><a href="./duvidas.php" class="nav-link">Dúvidas</li>
                <li class="nav-item"><a href="./catalogo.php" class="nav-link">Catálogo</li>
            </ul>
        </div>
    </nav>
    </header>
    <div class="duvida-font">
            <h1>Qual é a localização da loja?</h1>
            <h1>Qual é o nome da Empresa?</h1>
            <h1>Qual é o produto mais vendido?</h1>
    </div>
</body>
</html>