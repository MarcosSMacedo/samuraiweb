<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN IN</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<div class="box">
        <h2>Login</h2>
        <br>
        <form action="./login.php" method="POST" class='formLogin'>
            <label for="">E-mail</label>
            <input name="email" type="text" placeholder="Digite seu e-mail">
            <br><br>
            <label for="">Senha</label>
            <input name="senha" type="password" placeholder="Digite sua senha">

            <input type="submit" value="Entrar" class='btn'>
            <a href="./cadastro.php">Cadastre-se</a>
        </form>
    </div>
</body>
</html> 