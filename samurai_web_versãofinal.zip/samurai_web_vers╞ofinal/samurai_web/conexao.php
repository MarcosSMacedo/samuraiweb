<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "usuarios";

    $coat = mysqli_connect ($servername,  $username, $password, $dbname);

    if(!$coat) {
        die ("Connection Failed: ". mysqli_connect_error());
    }
?>