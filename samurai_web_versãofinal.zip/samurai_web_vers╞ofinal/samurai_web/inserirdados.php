<?php
    if($_POST['nome'] != ""){
        include_once './conexao.php';

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $cpf = $_POST['cpf'];
        $endereco = $_POST['endereco'];
        $senha = $_POST['senha'];

        $sql = "insert into dados (nome,email,cpf,endereco,senha)
        values('$nome','$email','$cpf','$endereco','$senha')";

        $query = mysqli_query($coat,$sql);

        echo 'Dados cadastrados com sucesso!';
    }

    else{
        echo 'Dados não cadastrados!';
    }
?>
<a href="./loginin.php">Entrar em sua conta</a>