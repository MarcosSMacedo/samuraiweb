<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CADASTRO</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <div class="box">
        <h2>Cadastre-se</h2>
        <form action="./inserirdados.php" method="POST">
            <label for="">Nome:</label>
        <input name="nome" type="text" placeholder="Digite seu nome">
    <br>
    <label for="">E-mail:</label>
<input name="email" type="email" placeholder="Digite seu e-mail">
<br>
<label for="">CPF:</label>
<input name="cpf" type="text" placeholder="Digite seu CPF">
<br>
<label for="">Endereço:</label>
<input name="endereco" type="text" placeholder="Digite seu endereço">
<br>
<label for="">Senha:</label>
<input name="senha" type="password" placeholder="Digite sua senha">
<br>
<input type="submit" value="Gravar">
</form>
</div>
</body>
</html>
 