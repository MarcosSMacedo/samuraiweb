<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<header>
    <nav class="nav-bar">
            <div class="logo">
                <h1>Catálogo</h1>
            </div>
        <div class="nav-list">
            <ul>
                <li class="nav-item"><a href="./index.php" class="nav-link">Início</li>
                <li class="nav-item"><a href="./sobrenos.php" class="nav-link">Sobre nós</li>
                <li class="nav-item"><a href="./duvidas.php" class="nav-link">Dúvidas</li>
                <li class="nav-item"><a href="./catalogo.php" class="nav-link">Catálogo</li>
            </ul>
        </div>
    </nav>
    </header>
    <div class="texto-edit">
        <p>Lâmpadas LED Inteligentes - Com controle de intensidade e cores via aplicativo. <br><br>
Fitas de LED RGB - Para decoração interna e externa com mudança de cor e programação de cenas.<br><br>
Painéis de LED Solares - Autossuficientes e ecológicos, ideais para áreas externas.<br><br>
Luminárias de LED Embutidas - Design moderno para um acabamento elegante em tetos.<br><br>
Refletores de LED - Alta potência para iluminação de fachadas e áreas amplas.<br><br>
Lâmpadas de LED Tubulares - Eficientes para escritórios e ambientes comerciais.<br><br>
Iluminação LED para Paisagismo - Realce a beleza natural de jardins e áreas verdes.<br><br>
Luzes de LED para Trilhos - Flexíveis e ajustáveis para galerias e vitrines.<br><br>
Lâmpadas de LED Anti-Inseto - Reduzem a presença de insetos, ideais para áreas externas.<br><br>
Sistemas de Iluminação LED Inteligentes - Integração com sistemas de automação residencial e comercial.<br><br>
</p>
    </div>
</body>
</html>