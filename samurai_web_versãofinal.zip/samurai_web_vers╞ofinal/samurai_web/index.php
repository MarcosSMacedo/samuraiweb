<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INDEX</title>
    <link rel="stylesheet" href="login.php">
    <link rel="stylesheet" href="cadastro.php">
    <link rel="stylesheet" href="css/estilo.css">
    <?php include_once './conexao.php'; ?>
    
</head>
<body>
    <header>
    <nav class="nav-bar">
            <div class="logo">
                <h1>Logo</h1>
            </div>
        <div class="nav-list">
            <ul>
                <li class="nav-item"><a href="./index.php" class="nav-link">Início</li>
                <li class="nav-item"><a href="./sobrenos.php" class="nav-link">Sobre nós</li>
                <li class="nav-item"><a href="./duvidas.php" class="nav-link">Dúvidas</li>
                <li class="nav-item"><a href="./catalogo.php" class="nav-link">Catálogo</li>
            </ul>
        </div>
        <div class="login-button">
            <button><a href="./loginin.php">Entrar</a></button>
        </div>
    </nav>
    </header>
    <br>
    <div id="bloco2">
        <img class="imagem-pequena" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlPItxqhKo81Kb2gcmKLioBMUb6KOl6ocfkg&s">
            <h4>Fita de LED - Comprar</h4>

        <img class="imagem-pequena" src="https://images.tcdn.com.br/img/img_prod/1135870/lampada_led_bulbo_t120_50w_6500k_e27_bivolt_991_1_a1fdba0d02ab810b7dd35c14c4b2bd25.png" alt="logo iluminacao-led">
            <h4>Bulbo 50W - Comprar</h4>

        <img class="imagem-pequena" src="https://cdn.awsli.com.br/800x800/508/508091/produto/209828589/design-sem-nome-37ny11o8jf.png">
            <h4>Perfil de LED - Comprar</h4>
            
    </div>
    <br><br><br>
    <div id="bloco2">
        <img class="imagem-pequena" src="https://cdn.awsli.com.br/600x1000/1842/1842150/produto/95548976/6cdef542cf.jpg">
            <h4>Lâmpada Tubular T8 - Comprar</h4>

        <img class="imagem-pequena" src="https://cdn.awsli.com.br/800x800/1327/1327356/produto/5260032399b5f43e5a.jpg" alt="logo iluminacao-led">
            <h4>Plafon de Embutir - Comprar</h4>

        <img class="imagem-pequena" src="https://images.tcdn.com.br/img/img_prod/435564/spot_led_quadrado_embutir_branco_5w_luz_amarela_3000k_3657_1_fac5b7254e8531511e8ca48c1cc68ef1.jpeg">
            <h4>Spot - Comprar</h4>
            
    </div>
    <br>
    <footer> 
    <p>Facebook</p>
    <p>Whatsapp</p>
    <p>Endereço: Av.Papa Pio XII nº 608 </p>
    </footer>
</body>
</html>