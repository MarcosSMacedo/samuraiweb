<?php

    include_once("./conexao.php");

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM dados WHERE email='$email' and senha='$senha' ";

    $sql_query = $coat->query($sql);
    $result = $sql_query->fetch_assoc();

    if($sql_query->num_rows){
        session_start();
        $SESSION['email'] = $result ['email'];
        
    }
    else{
        echo "Usuário não encontrado";
    }

?>
<a href="./loginin.php">Voltar</a>
<a href="./index.php">Entrar no site</a>
