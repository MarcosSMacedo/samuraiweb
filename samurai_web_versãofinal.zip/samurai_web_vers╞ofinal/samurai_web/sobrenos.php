<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre nós</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<header>
    <nav class="nav-bar">
            <div class="logo">
                <h1>Sobre Nós</h1>
            </div>
        <div class="nav-list">
            <ul>
                <li class="nav-item"><a href="./index.php" class="nav-link">Início</li>
                <li class="nav-item"><a href="./sobrenos.php" class="nav-link">Sobre nós</li>
                <li class="nav-item"><a href="./duvidas.php" class="nav-link">Dúvidas</li>
                <li class="nav-item"><a href="./catalogo.php" class="nav-link">Catálogo</li>
            </ul>
        </div>
    </nav>

    </header>
<br><br>
    <div id="foto-loja">
        <img class="imagem-pequena" src="./img/dentro-loja2.jpg" alt="sobre-nos-foto">
        <h1>Sobre a Samurai LED</h1>
        <p>
Iluminando o caminho para um futuro mais brilhante, a Samurai LED se destaca como um farol de inovação no mercado de iluminação LED há mais de uma década. Nossa jornada começou com a visão de trazer produtos de alta qualidade que não apenas iluminam espaços, mas também inspiram vidas.

Com uma herança enraizada na tradição e excelência, cada LED que produzimos carrega o espírito do bushido - o caminho do guerreiro. Assim como os samurais eram mestres em sua arte, nós somos mestres na arte de criar soluções de iluminação que são eficientes, duráveis e esteticamente agradáveis.

Nossa paixão por inovação nos levou a desenvolver uma gama de produtos que não só atendem, mas superam as expectativas dos nossos clientes. De residências a escritórios, de lojas a espaços industriais, a Samurai LED oferece uma solução de iluminação para cada necessidade.

Junte-se a nós nesta jornada iluminada e descubra como a Samurai LED pode transformar seu espaço com a luz perfeita.</p>
    </div>
    <div id="foto-loja">
        <img class="imagem-pequena" src="./img/fora-loja.jpg" alt="sobre-nos-foto">
</body>
</html>